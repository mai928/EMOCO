const i18nConfig = {
    locales: ['en', 'ar', 'fr'],
    defaultLocale: 'en'
  };
  
  module.exports = i18nConfig;