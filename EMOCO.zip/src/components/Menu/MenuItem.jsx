import React from 'react'

const MenuItem = () => {
  return (
    <div>MenuItem</div>
  )
}

export default MenuItem