import React from 'react'
import MainVideo from './MainVideo'

const MainComponets = ({params}) => {
  return (
   <section className='h-screen'>
    <MainVideo params={params}/>
   </section>
  )
}

export default MainComponets